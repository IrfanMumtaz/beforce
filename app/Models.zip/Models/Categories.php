<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

use Illuminate\Database\Eloquent\SoftDeletes;


class Categories extends Model
{
    use SoftDeletes;

    public $table = 'categories';
    

    protected $dates = ['deleted_at'];


    public $fillable = [
        'undefined',
        'Category',
        'Competition',
        'brand',
        'brandId'

    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'Category' => 'string',
        'Competition' => 'boolean',
        'brand' => 'string',
	'brandId' => 'Interger'

    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [

        'Category'=> 'required',
        'brand'=> 'required',


    ];
}
