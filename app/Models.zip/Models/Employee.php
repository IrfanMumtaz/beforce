<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

use Illuminate\Database\Eloquent\SoftDeletes;


class Employee extends Model
{
    use SoftDeletes;

    public $table = 'employees';
    
    protected $dates = ['deleted_at'];
	
    public $guarded = ['id'];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'Username' => 'string',
        'Password' => 'string',
        'Designation' => 'string',
        'email' => 'string',
        'EmployeeName' => 'string',
        'FatherName' => 'string',
        'SpouseName' => 'string',
        'DOB' => 'string',
        'CNIC' => 'string',
        'FamilyCode' => 'string',
        'Nationality' => 'string',
        'PostalAddress' => 'string',
        'ContactNumber' => 'string',
        'EmployeeNo' => 'string',
        'Gender' => 'string',
        'religion' => 'string',
        'NatureofEmployment' => 'string',
        'DateOfDeployment' => 'string',
        'NTN' => 'string',
        'EOBINO' => 'string',
        'InsuranceEntitlement' => 'string',
        'BankAccountNo' => 'string',
        'BankBranchName' => 'string',
        'BankBranchCity' => 'string',
        'BloodGroup' => 'string',
        'AcademicQalification' => 'string',
        'District' => 'string',
        'Proviance' => 'string',
        'MaritalStatus' => 'string',
        'MonthlySalary' => 'integer',
        'Allowances' => 'integer',
        'ResidentialCity' => 'string',
        'Department' => 'string',
        'UserAvatar' => 'string',
	'CNICIMG' => 'string',
	'SelectBrand' => 'string',
  	'ShopCity' => 'string',
    	'Shop' => 'string',
	'Reporting1' => 'string',
	'Reporting2' => 'string',
	'MailingAddress' => 'string',
	'Country' => 'string',
	'State' => 'string',
	'ZipCode' => 'string',
	'EmployeeStatus' => 'string',
	'AttenStartTime' => 'string',
	'Monday' => 'integer',
	'Tuesday' => 'integer',
      	'Wednesday' => 'integer',
      	'Thursday' => 'integer',
      	'Friday' => 'integer',
      	'Saturday' => 'integer',
      	'Sunday' => 'integer',
	'brandId' => 'integer'
];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
      'Username' => 'required|unique:employees|max:120',
        'Password' => 'required',
        'Designation' => 'required',
        'email' => 'required|unique:employees',
        'EmployeeName' => 'required|max:120',
        'FatherName' => 'required|max:120',
        'SpouseName' => 'required|max:120',
        'DOB' => 'required',
        'CNIC' => 'required',
        'FamilyCode' => 'required',
        'Nationality' => 'required',
        'PostalAddress' => 'required',
        'ContactNumber' => 'required|regex:/(92)[0-9]{9}/',
        'EmployeeNo' => 'required',
        'Nationality' => 'required',
        'Gender' => 'required',
        'religion' => 'required',
        'DateOfDeployment' => 'required',
        'NatureofEmployment' => 'required',
        'NTN' => 'required',
        'EOBINO' => 'required',
        'InsuranceEntitlement' => 'required',
        'BankAccountNo' => 'required',
        'BankBranchName' => 'required',
        'BankBranchCity' => 'required',
        'BloodGroup' => 'required',
        'AcademicQalification' => 'required',
        'MaritalStatus' => 'required',
        'MonthlySalary' => 'required',
        'Allowances' => 'required',
        'ResidentialCity' => 'required',
        'UserAvatar' => 'required',
        'CNICIMG' => 'required',
        'SelectBrand' => 'required',
        'ShopCity' => 'required',
        'Shop' => 'required',
        'Reporting1' => 'required',
        'Reporting2' => 'required',
        'MailingAddress' => 'required',
        'Country' => 'required',
        'State' => 'required',
        'ZipCode' => 'required',
        'EmployeeStatus' => 'required',
        'AttenStartTime' => 'required',
        'District' => 'required',
        'Proviance' => 'required',
        'Department' => 'required'
    ];



}
