<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

use Illuminate\Database\Eloquent\SoftDeletes;


class Brands extends Model
{
    use SoftDeletes;

    public $table = 'brands';
    

    protected $dates = ['deleted_at'];


    public $fillable = [
        'BrandName',
        'Description',
        'SelectManagers',
        'SelectSupervisors',
        'SelectMerchandisers',
        'SelectDamageVerification',
        'SelectEmloyee',
        'BrandCities',
	'created_at'
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'BrandName' => 'string',
        'Description' => 'string',
        'SelectManagers' => 'array',
        'SelectSupervisors' => 'array',
        'SelectMerchandisers' => 'array',
        'SelectDamageVerification' => 'array',
        'SelectEmloyee' => 'array',
        'BrandCities' => 'array'
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        
        'BrandName'=> 'required',
        'BrandCities'=> 'required'


    ];


public function Employee()
    {
       return $this->hasMany(Employee::class);
    }


}
