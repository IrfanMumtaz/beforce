<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

use Illuminate\Database\Eloquent\SoftDeletes;


class Stores extends Model
{
    use SoftDeletes;

    public $table = 'shops';
    

    protected $dates = ['deleted_at'];


    public $fillable = [
        'undefined',
        'name',
        'Ownername',
        'Contactperson',
        'Contactnumber',
        'latitude',
        'longitude',
        'Storesize',
        'Region',
        'Storecity',
	'created_at'
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'name' => 'string',
        'Ownername' => 'string',
        'Contactperson' => 'string',
        'Contactnumber' => 'string',
        'latitude' => 'string',
        'longitude' => 'string',
        'Storesize' => 'string',
        'Region' => 'string',
        'Storecity' => 'string'
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'name' => 'required',
        'Region' => 'required',
        'latitude'=> 'required',
        'longitude'=> 'required',
        'Storesize'=> 'required',
        'Storecity'=> 'required'



	    ];
}
