<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

use Illuminate\Database\Eloquent\SoftDeletes;


class SKU extends Model
{
    use SoftDeletes;

    public $table = 'skus';
    

    protected $dates = ['deleted_at'];


    public $fillable = [
        'SKUCaategory',
        'name',
        'Price',
        'ItemPerCarton',
        'SKUImage',
	'Brand',
	'brandId',
	'CateId'

    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'SKUCaategory' => 'string',
        'name' => 'string',
        'Price' => 'integer',
        'ItemPerCarton' => 'integer',
        'SKUImage' => 'string'
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'CateId' => 'required',
        'name' => 'required',
        'Price' => 'required',
        'ItemPerCarton' => 'required'
    ];
}
